<!-- Tufts VUE 3.2.2 concept-map (Seleccionar_Temas.vue) 2013-10-21 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Mon Oct 21 12:32:07 COT 2013 by Toshiba on platform Windows 7 6.1 in JVM 1.7.0_21-b11 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 23 2013 at 2146 by tomadm on Linux 2.6.18-348.2.1.el5 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="Seleccionar_Temas.vue" created="1382028171939" x="0.0"
    y="0.0" width="837.0" height="596.25" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1382376727328"
        spec="C:\Users\Toshiba\Downloads\Seleccionar_Temas\Seleccionar_Temas.vue"
        type="1" xsi:type="URLResource">
        <title>Seleccionar_Temas.vue</title>
        <property key="File" value="C:\Users\Toshiba\Downloads\Seleccionar_Temas\Seleccionar_Temas.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/c75635caac11013201415ce6e48fc90c</URIString>
    <child ID="6" label="Seleccionar Temas " layerID="1"
        created="1382028178732" x="433.1653" y="-21.5" width="121.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce63f12ec60</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="7" label="Verificar autorizaciones" layerID="1"
        created="1382028201802" x="427.91983" y="68.0" width="138.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce674b0241d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="9" label="Presenta interfaz de error" layerID="1"
        created="1382028241760" x="651.34875" y="250.56857"
        width="149.0" height="37.026703" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce6f2675adf</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="10" label="NOK" layerID="1" created="1382028275628"
        x="510.30658" y="90.5" width="193.68637" height="160.56854"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce6b6422cbd</URIString>
        <point1 x="510.8066" y="91.0"/>
        <point2 x="703.493" y="250.56854"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="13" label="Presenta la interfaz de Jerarquizar&#xa;"
        layerID="1" created="1382028306188" x="187.27025" y="149.20413"
        width="205.90675" height="38.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce62a867e06</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="14" label="OK" layerID="1" created="1382028363078"
        x="333.997" y="90.5" width="136.6258" height="59.204132"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce6b1bd9cec</URIString>
        <point1 x="470.1228" y="91.0"/>
        <point2 x="334.497" y="149.20413"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="15" label="Valida Datos" layerID="1"
        created="1382028403342" x="251.40826" y="317.2661" width="81.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce615e5ab1b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="16" label="Aceptar" layerID="1" created="1382028455136"
        x="271.6053" y="186.70508" width="39.0" height="131.06055"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce6faff15da</URIString>
        <point1 x="290.42297" y="187.20508"/>
        <point2 x="291.7876" y="317.26562"/>
        <ID1 xsi:type="node">13</ID1>
        <ID2 xsi:type="node">15</ID2>
    </child>
    <child ID="19" label="NOK" layerID="1" created="1382028517388"
        x="327.19714" y="279.87854" width="142.41312" height="39.6149"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce601005d9f</URIString>
        <point1 x="327.6971" y="318.99344"/>
        <point2 x="469.11023" y="280.37854"/>
        <ID1 xsi:type="node">15</ID1>
        <ID2 xsi:type="node">20</ID2>
    </child>
    <child ID="20" label="Presenta interfaz de error" layerID="1"
        created="1382028528710" x="436.72482" y="257.37854"
        width="149.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cdac11013201415ce649b334e1</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="21" label="Aceptar" layerID="1" created="1382028537626"
        x="541.31616" y="287.0952" width="174.0597" height="292.98285"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cdac11013201415ce67d391878</URIString>
        <point1 x="714.87585" y="287.5952"/>
        <point2 x="541.81616" y="579.57806"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">36</ID2>
    </child>
    <child ID="25" label="Aceptar" layerID="1" created="1382028593655"
        x="331.43256" y="186.70413" width="155.0474" height="71.17441"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cdac11013201415ce6ab04e6f3</URIString>
        <point1 x="485.97995" y="257.37854"/>
        <point2 x="331.93256" y="187.20413"/>
        <ID1 xsi:type="node">20</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="17" label="OK" layerID="1" created="1382028460127"
        x="287.20868" y="339.7661" width="15.0" height="64.387695"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ceac11013201415ce6b9db0a17</URIString>
        <point1 x="292.65384" y="340.2661"/>
        <point2 x="296.7635" y="403.6538"/>
        <ID1 xsi:type="node">15</ID1>
        <ID2 xsi:type="node">27</ID2>
    </child>
    <child ID="27" label="Registra" layerID="1" created="1382028635110"
        x="268.50906" y="403.65375" width="58.0" height="23.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ceac11013201415ce66fbc7c4c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="28" label="Presenta interfaz de confirmaci&#xf3;n"
        layerID="1" created="1382028650381" x="201.81403" y="504.53226"
        width="194.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ceac11013201415ce65af9fe7c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="29" label="OK" layerID="1" created="1382028669507"
        x="290.66156" y="426.1543" width="15.0" height="78.87891"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ceac11013201415ce60f92fbd2</URIString>
        <point1 x="297.65784" y="426.6543"/>
        <point2 x="298.66528" y="504.5332"/>
        <ID1 xsi:type="node">27</ID1>
        <ID2 xsi:type="node">28</ID2>
    </child>
    <child ID="34" label="NOK" layerID="1" created="1382028728965"
        x="325.8858" y="279.87842" width="184.68356" height="133.66476"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cfac11013201415ce6f94e9a4c</URIString>
        <point1 x="326.3858" y="413.04318"/>
        <point2 x="510.06937" y="280.37842"/>
        <ID1 xsi:type="node">27</ID1>
        <ID2 xsi:type="node">20</ID2>
        <ctrlPoint0 x="498.0" y="400.5" xsi:type="point"/>
    </child>
    <child ID="36" label="Regresa a HOME" layerID="1"
        created="1382028750540" x="481.5" y="579.5781" width="107.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cfac11013201415ce68aacbb4a</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="37" label="Aceptar" layerID="1" created="1382028750540"
        x="334.50705" y="527.0322" width="164.79993" height="53.0459"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce68f075c0c</URIString>
        <point1 x="335.00705" y="527.5322"/>
        <point2 x="498.80698" y="579.5781"/>
        <ID1 xsi:type="node">28</ID1>
        <ID2 xsi:type="node">36</ID2>
    </child>
    <child ID="40" label="ingresa" layerID="1" created="1382045465349"
        x="477.29257" y="1.0" width="36.0" height="67.5"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c85776e1ac11013201415ce6883fa2be</URIString>
        <point1 x="494.0835" y="1.5"/>
        <point2 x="496.50165" y="68.0"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="41" label="M&#xf3;dulo Seleccionar &#xa;Temas"
        layerID="1" created="1382045881265" x="630.85535" y="-25.183468"
        width="143.69998" height="54.700005" strokeWidth="1.0"
        autoSized="true" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce6e0a2d7ae</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="42"
        label="-Un tema debe ser seleccionado &#xa;unicamente por un estudiante.&#xa;- No seleccionar m&#xe1;s de tres temas."
        layerID="1" created="1382046085696" x="-52.247982" y="286.0"
        width="211.0" height="72.6391" strokeWidth="1.0" strokeStyle="3"
        autoSized="false" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce69edc06b7</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="43" layerID="1" created="1382046173129" x="158.25201"
        y="324.6693" width="93.65625" height="3.5028381"
        strokeWidth="1.0" strokeStyle="3" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce6a4b87d35</URIString>
        <point1 x="158.75201" y="325.1693"/>
        <point2 x="251.40826" y="327.67215"/>
        <ID1 xsi:type="node">42</ID1>
        <ID2 xsi:type="node">15</ID2>
    </child>
    <child ID="45"
        label="- Debe seleccionar un estudiante &#xa;matriculado en Plan de Titulaci&#xf3;n"
        layerID="1" created="1382046193495" x="125.89212" y="59.032257"
        width="196.0" height="38.0" strokeWidth="1.0" strokeStyle="3"
        autoSized="true" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce69545ee92</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="46" layerID="1" created="1382046193495" x="321.39212"
        y="78.05909" width="107.02771" height="1.5699768"
        strokeWidth="1.0" strokeStyle="3" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624441ac11013201415ce672b7f4c4</URIString>
        <point1 x="321.89212" y="78.55909"/>
        <point2 x="427.91983" y="79.12907"/>
        <ID1 xsi:type="node">45</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="47"
        label="- Un estudiante puede seleccionar &#xa;hasta tres Temas de acuerdo a sus &#xa;gustos o afinidad y colocarlos en un rango &#xa;de su  preferencia&#xa;"
        layerID="1" created="1382046302380" x="-87.35585" y="135.5"
        width="246.0" height="83.0" strokeWidth="1.0" strokeStyle="3"
        autoSized="true" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624441ac11013201415ce68b66ca52</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="48" layerID="1" created="1382046302380" x="158.14415"
        y="171.26123" width="29.626099" height="1.9890442"
        strokeWidth="1.0" strokeStyle="3" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624441ac11013201415ce60ba00ccd</URIString>
        <point1 x="158.64415" y="172.75027"/>
        <point2 x="187.27025" y="171.76123"/>
        <ID1 xsi:type="node">47</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <layer ID="1" label="Layer 1" created="1382028171940" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce6507fa775</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-113.0" y="-80.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1382028171939"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="0" open="true">
            <strokeColor>#B3CC33CC</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce668a21590</URIString>
            <masterSlide ID="2" created="1382028171967" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce60adc6f7d</URIString>
                <titleStyle ID="3" label="Header"
                    created="1382028171992" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/c75635d1ac11013201415ce6479d9779</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1382028171992" x="346.5" y="281.5"
                    width="107.0" height="37.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/c75635d1ac11013201415ce6e330ec9d</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1382028171993"
                    x="373.5" y="384.0" width="53.0" height="32.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/c75635d1ac11013201415ce617927fba</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2013-10-17</date>
    <modelVersion>6</modelVersion>
    <saveLocation>C:\Users\Toshiba\Downloads\Seleccionar_Temas</saveLocation>
    <saveFile>C:\Users\Toshiba\Downloads\Seleccionar_Temas\Seleccionar_Temas.vue</saveFile>
</LW-MAP>
