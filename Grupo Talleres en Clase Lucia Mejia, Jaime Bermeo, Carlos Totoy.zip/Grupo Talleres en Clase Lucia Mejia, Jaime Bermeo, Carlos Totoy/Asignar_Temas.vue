<!-- Tufts VUE 3.2.2 concept-map (Asignar_Temas.vue) 2013-10-21 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/C:/Program%20Files%20(x86)/VUE/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Mon Oct 21 12:55:14 COT 2013 by Toshiba on platform Windows 7 6.1 in JVM 1.7.0_21-b11 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 23 2013 at 2146 by tomadm on Linux 2.6.18-348.2.1.el5 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="Asignar_Temas.vue" created="1382028171939" x="0.0" y="0.0"
    width="837.0" height="596.25" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1382378114980"
        spec="C:\Users\Toshiba\Downloads\Seleccionar_Temas\Asignar_Temas.vue"
        type="1" xsi:type="URLResource">
        <title>Asignar_Temas.vue</title>
        <property key="File" value="C:\Users\Toshiba\Downloads\Seleccionar_Temas\Asignar_Temas.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/c75635caac11013201415ce6e48fc90c</URIString>
    <child ID="6" label="Asignar Temas" layerID="1"
        created="1382028178732" x="448.81903" y="-21.5" width="95.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce63f12ec60</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="7" label="Verificar autorizaciones" layerID="1"
        created="1382028201802" x="427.91983" y="68.0" width="138.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce674b0241d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="9" label="Presenta interfaz de error" layerID="1"
        created="1382028241760" x="651.34875" y="250.56857"
        width="149.0" height="37.026703" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce6f2675adf</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="10" label="NOK" layerID="1" created="1382028275628"
        x="510.30658" y="90.5" width="193.68637" height="160.56854"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cbac11013201415ce6b6422cbd</URIString>
        <point1 x="510.8066" y="91.0"/>
        <point2 x="703.493" y="250.56854"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="13" label="Presenta la interfaz de Autorizar&#xa;"
        layerID="1" created="1382028306188" x="208.94464" y="176.89919"
        width="189.04889" height="38.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce62a867e06</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="14" label="OK" layerID="1" created="1382028363078"
        x="334.54633" y="90.49999" width="143.76096" height="86.899185"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce6b1bd9cec</URIString>
        <point1 x="477.80728" y="91.0"/>
        <point2 x="335.04633" y="176.89919"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="16" label="Aceptar" layerID="1" created="1382028455136"
        x="286.9585" y="214.3994" width="39.0" height="104.57034"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce6faff15da</URIString>
        <point1 x="304.27148" y="214.89941"/>
        <point2 x="308.64548" y="318.46976"/>
        <ID1 xsi:type="node">13</ID1>
    </child>
    <child ID="19" label="NOK" layerID="1" created="1382028517388"
        x="327.1971" y="267.83722" width="177.06824" height="51.65622"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ccac11013201415ce601005d9f</URIString>
        <point1 x="327.6971" y="318.99344"/>
        <point2 x="503.76535" y="268.33722"/>
        <ID2 xsi:type="node">20</ID2>
    </child>
    <child ID="20" label="Presenta interfaz de error" layerID="1"
        created="1382028528710" x="469.23642" y="245.33722"
        width="149.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cdac11013201415ce649b334e1</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="21" label="Aceptar" layerID="1" created="1382028537626"
        x="534.8582" y="287.09528" width="167.6521" height="130.4249"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cdac11013201415ce67d391878</URIString>
        <point1 x="702.0103" y="287.59528"/>
        <point2 x="535.3582" y="417.02017"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">36</ID2>
    </child>
    <child ID="25" label="Aceptar" layerID="1" created="1382028593655"
        x="377.88257" y="214.39917" width="121.011475"
        height="31.438034" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cdac11013201415ce6ab04e6f3</URIString>
        <point1 x="498.39404" y="245.33722"/>
        <point2 x="378.38257" y="214.89919"/>
        <ID1 xsi:type="node">20</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="28" label="Autoriza" layerID="1" created="1382028650381"
        x="269.2455" y="320.2999" width="82.99097" height="23.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635ceac11013201415ce65af9fe7c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="36" label="Regresa a HOME" layerID="1"
        created="1382028750540" x="467.0504" y="417.02014" width="107.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635cfac11013201415ce68aacbb4a</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="37" label="Aceptar" layerID="1" created="1382028750540"
        x="335.18726" y="342.79993" width="160.9169" height="74.720245"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce68f075c0c</URIString>
        <point1 x="335.68726" y="343.2999"/>
        <point2 x="495.60416" y="417.02014"/>
        <ID1 xsi:type="node">28</ID1>
        <ID2 xsi:type="node">36</ID2>
    </child>
    <child ID="40" label="ingresa" layerID="1" created="1382045465349"
        x="478.61945" y="1.0" width="36.0" height="67.5"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c85776e1ac11013201415ce6883fa2be</URIString>
        <point1 x="496.3962" y="1.5"/>
        <point2 x="496.84265" y="68.0"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="41" label="M&#xf3;dulo Asignar &#xa;Temas" layerID="1"
        created="1382045881265" x="630.85535" y="-25.183468"
        width="117.799995" height="51.799995" strokeWidth="1.0"
        autoSized="true" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce6e0a2d7ae</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="42"
        label="Una vez asigando el tema a un estudiante &#xa;el Decano debe Autorizar el Tema de Tesis."
        layerID="1" created="1382046085696" x="-49.83971" y="299.24545"
        width="250.0" height="72.6391" strokeWidth="1.0" strokeStyle="3"
        autoSized="false" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce69edc06b7</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="43" layerID="1" created="1382046173129" x="199.66031"
        y="335.4209" width="64.28932" height="1.1802063"
        strokeWidth="1.0" strokeStyle="3" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce6a4b87d35</URIString>
        <point1 x="200.1603" y="335.92087"/>
        <point2 x="263.44962" y="336.10107"/>
        <ID1 xsi:type="node">42</ID1>
    </child>
    <child ID="45"
        label="ElDocente debe verificar los temas que &#xa;selecciono cada estudiante"
        layerID="1" created="1382046193495" x="125.89212" y="59.032257"
        width="229.0" height="38.0" strokeWidth="1.0" strokeStyle="3"
        autoSized="true" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624440ac11013201415ce69545ee92</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="46" layerID="1" created="1382046193495" x="354.39212"
        y="78.18738" width="74.02771" height="1.4178314"
        strokeWidth="1.0" strokeStyle="3" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624441ac11013201415ce672b7f4c4</URIString>
        <point1 x="354.89212" y="78.68738"/>
        <point2 x="427.91983" y="79.10521"/>
        <ID1 xsi:type="node">45</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="47"
        label="- El Docente debe asignar el tema &#xa;que el estudiante haya seleccionado"
        layerID="1" created="1382046302380" x="-84.947586" y="166.80746"
        width="246.0" height="50.948074" strokeWidth="1.0"
        strokeStyle="3" autoSized="false" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624441ac11013201415ce68b66ca52</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="48" layerID="1" created="1382046302380" x="160.55243"
        y="193.45801" width="48.892227" height="1.6527863"
        strokeWidth="1.0" strokeStyle="3" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/c8624441ac11013201415ce60ba00ccd</URIString>
        <point1 x="161.05241" y="193.95801"/>
        <point2 x="208.94464" y="194.6108"/>
        <ID1 xsi:type="node">47</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="60" layerID="1" created="1382377716777" x="533.15173"
        y="255.73358" width="11.084656" height="1.6036377"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc280fb2c0a8010301eb17ce4c1cad22</URIString>
        <point1 x="543.73645" y="256.83722"/>
        <point2 x="533.6518" y="256.23358"/>
        <ID1 xsi:type="node">20</ID1>
    </child>
    <layer ID="1" label="Layer 1" created="1382028171940" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce6507fa775</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="-113.0" y="-80.0"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1382028171939"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="0" open="true">
            <strokeColor>#B3CC33CC</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce668a21590</URIString>
            <masterSlide ID="2" created="1382028171967" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/c75635d0ac11013201415ce60adc6f7d</URIString>
                <titleStyle ID="3" label="Header"
                    created="1382028171992" x="335.5" y="172.5"
                    width="129.0" height="55.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/c75635d1ac11013201415ce6479d9779</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1382028171992" x="346.5" y="281.5"
                    width="107.0" height="37.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/c75635d1ac11013201415ce6e330ec9d</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1382028171993"
                    x="373.5" y="384.0" width="53.0" height="32.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/c75635d1ac11013201415ce617927fba</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2013-10-17</date>
    <modelVersion>6</modelVersion>
    <saveLocation>C:\Users\Toshiba\Downloads\Seleccionar_Temas</saveLocation>
    <saveFile>C:\Users\Toshiba\Downloads\Seleccionar_Temas\Asignar_Temas.vue</saveFile>
</LW-MAP>
